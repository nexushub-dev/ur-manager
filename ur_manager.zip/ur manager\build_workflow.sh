#!/usr/bin/env bash
# =============================================================================
#  build_workflow.sh — Content Checklist Mobile Build Script
#  Part 4: Packaging — Android (.apk) and iOS (.ipa)
# =============================================================================
#  Usage:
#    chmod +x build_workflow.sh
#    ./build_workflow.sh android          # Build debug APK
#    ./build_workflow.sh android release  # Build release APK (needs keystore)
#    ./build_workflow.sh ios              # Build debug IPA (macOS only)
#    ./build_workflow.sh clean            # Wipe build artifacts
#    ./build_workflow.sh check            # Verify environment only
#
#  Prerequisites:
#    Android: Ubuntu/Debian Linux, Python 3.10+, Java 17, Git, pip
#    iOS    : macOS 13+, Xcode 15+, Python 3.10+, pip, brew
# =============================================================================

set -euo pipefail

# ─── Colour helpers ───────────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; RESET='\033[0m'

info()    { echo -e "${CYAN}[INFO]${RESET} $*"; }
success() { echo -e "${GREEN}[OK]${RESET}   $*"; }
warn()    { echo -e "${YELLOW}[WARN]${RESET} $*"; }
error()   { echo -e "${RED}[ERR]${RESET}  $*" >&2; }
header()  { echo -e "\n${BOLD}${CYAN}══ $* ══${RESET}"; }

# ─── Config ───────────────────────────────────────────────────────────────────
APP_NAME="ContentChecklist"
PYTHON_MIN="3.10"
JAVA_VERSION="17"
BUILDOZER_VERSION="1.5.0"

ANDROID_TARGET="${2:-debug}"   # debug or release
BUILD_DIR=".buildozer"
BIN_DIR="bin"

# ─── Helpers ──────────────────────────────────────────────────────────────────
require_command() {
    if ! command -v "$1" &>/dev/null; then
        error "Required command not found: $1"
        error "Install it and re-run this script."
        exit 1
    fi
}

check_python_version() {
    local ver
    ver=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
    if python3 -c "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)"; then
        success "Python $ver detected (>= $PYTHON_MIN required)"
    else
        error "Python $PYTHON_MIN+ required. Found: $ver"
        exit 1
    fi
}

check_java_version() {
    if command -v java &>/dev/null; then
        local jver
        jver=$(java -version 2>&1 | head -1 | grep -oP '(?<=version ")[^"]+' || echo "unknown")
        success "Java detected: $jver"
    else
        warn "Java not found. Installing OpenJDK $JAVA_VERSION ..."
        sudo apt-get update -qq && sudo apt-get install -y "openjdk-${JAVA_VERSION}-jdk"
    fi
}

# ─── Environment verification ─────────────────────────────────────────────────
cmd_check() {
    header "Environment Check"

    check_python_version
    check_java_version
    require_command git
    require_command pip3

    if pip3 show buildozer &>/dev/null; then
        local bver
        bver=$(pip3 show buildozer | grep Version | awk '{print $2}')
        success "buildozer $bver installed"
    else
        warn "buildozer not installed — will install now"
        install_buildozer
    fi

    if [[ "$(uname)" == "Darwin" ]]; then
        require_command xcodebuild
        local xver
        xver=$(xcodebuild -version 2>/dev/null | head -1)
        success "Xcode: $xver"
    fi

    success "Environment check passed."
}

# ─── Installation ─────────────────────────────────────────────────────────────
install_buildozer() {
    header "Installing Buildozer"

    # System dependencies (Ubuntu/Debian)
    if command -v apt-get &>/dev/null; then
        info "Installing system dependencies ..."
        sudo apt-get update -qq
        sudo apt-get install -y \
            python3-pip \
            build-essential \
            git \
            ffmpeg \
            libsdl2-dev \
            libsdl2-image-dev \
            libsdl2-mixer-dev \
            libsdl2-ttf-dev \
            libportmidi-dev \
            libswscale-dev \
            libavformat-dev \
            libavcodec-dev \
            libunwind-dev \
            zlib1g-dev \
            zip \
            unzip \
            autoconf \
            libtool \
            pkg-config \
            cmake \
            libffi-dev \
            libssl-dev
    fi

    pip3 install --upgrade \
        "buildozer==${BUILDOZER_VERSION}" \
        cython \
        virtualenv

    success "Buildozer $BUILDOZER_VERSION installed."
}

# ─── Pre-build validation ─────────────────────────────────────────────────────
pre_build_check() {
    header "Pre-build Validation"

    [[ -f "buildozer.spec" ]] || { error "buildozer.spec not found. Run from project root."; exit 1; }
    [[ -f "main.py" ]]        || { error "main.py not found. Ensure entry point exists."; exit 1; }
    [[ -f "AndroidManifest.xml" ]] || warn "AndroidManifest.xml not found — Buildozer will generate a default one."
    [[ -f "Info.plist" ]]     || warn "Info.plist not found — required for iOS builds."

    mkdir -p "$BIN_DIR" assets

    # Validate no placeholder package name remains
    if grep -q "com.yourapp" buildozer.spec 2>/dev/null; then
        warn "buildozer.spec still contains placeholder package domain 'com.yourapp'."
        warn "Update 'package.domain' before making a release build."
    fi

    success "Pre-build validation done."
}

# ─── Android Build ────────────────────────────────────────────────────────────
cmd_android() {
    header "Building Android ${ANDROID_TARGET^^}"

    cmd_check
    pre_build_check

    info "Starting Buildozer Android $ANDROID_TARGET build ..."
    info "This can take 10–30 minutes on first run (SDK/NDK download)."
    echo ""

    if [[ "$ANDROID_TARGET" == "release" ]]; then
        warn "Release build: ensure keystore variables are set in buildozer.spec"
        buildozer -v android release 2>&1 | tee "build_android_release.log"
    else
        buildozer -v android debug 2>&1 | tee "build_android_debug.log"
    fi

    # Find the output APK
    local apk_path
    apk_path=$(find "$BIN_DIR" -name "*.apk" | sort -t '_' -k3 -r | head -1)

    if [[ -n "$apk_path" ]]; then
        local size
        size=$(du -sh "$apk_path" | cut -f1)
        success "APK built successfully!"
        success "  Path : $apk_path"
        success "  Size : $size"
        echo ""
        info "To install on a connected device:"
        info "  adb install -r $apk_path"
    else
        error "No APK found in $BIN_DIR. Check build log for errors."
        exit 1
    fi
}

# ─── iOS Build ────────────────────────────────────────────────────────────────
cmd_ios() {
    header "Building iOS Debug IPA"

    if [[ "$(uname)" != "Darwin" ]]; then
        error "iOS builds require macOS with Xcode installed."
        error "Run this script on a Mac."
        exit 1
    fi

    cmd_check
    pre_build_check

    info "Checking kivy-ios toolchain ..."
    if ! command -v toolchain &>/dev/null; then
        info "Installing kivy-ios toolchain ..."
        pip3 install kivy-ios
        toolchain build python3 kivy
    fi

    info "Building iOS project ..."
    buildozer -v ios debug 2>&1 | tee "build_ios_debug.log"

    local ipa_path
    ipa_path=$(find "$BIN_DIR" -name "*.ipa" | head -1)

    if [[ -n "$ipa_path" ]]; then
        local size
        size=$(du -sh "$ipa_path" | cut -f1)
        success "IPA built successfully!"
        success "  Path : $ipa_path"
        success "  Size : $size"
        echo ""
        info "To deploy to a device: open the Xcode project in $BUILD_DIR/ios/"
        info "Or use: xcrun altool --upload-app -f $ipa_path (requires Apple account)"
    else
        warn "No IPA found — the build may have produced an .xcarchive instead."
        warn "Open Xcode and use Product → Archive → Distribute App."
    fi
}

# ─── Clean ────────────────────────────────────────────────────────────────────
cmd_clean() {
    header "Cleaning Build Artifacts"
    info "Removing $BUILD_DIR/ and $BIN_DIR/ ..."
    rm -rf "$BUILD_DIR" "$BIN_DIR" __pycache__ .pytest_cache
    find . -name "*.pyc" -delete
    success "Clean complete."
}

# ─── Main dispatcher ──────────────────────────────────────────────────────────
TARGET="${1:-help}"

case "$TARGET" in
    android) cmd_android ;;
    ios)     cmd_ios ;;
    clean)   cmd_clean ;;
    check)   cmd_check ;;
    *)
        echo -e "${BOLD}Usage:${RESET}"
        echo "  ./build_workflow.sh android [debug|release]"
        echo "  ./build_workflow.sh ios"
        echo "  ./build_workflow.sh clean"
        echo "  ./build_workflow.sh check"
        exit 0
        ;;
esac
