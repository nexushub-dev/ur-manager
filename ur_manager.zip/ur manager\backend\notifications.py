"""
notifications.py — Daily Notification System
Part 4: System Integrations
------------------------------------------------------------
Sends a passive-aggressive "Edit and Post" reminder at 9 PM
if any checklist item is still unfinished.
Uses plyer for cross-platform desktop/mobile notifications,
with a threading-based scheduler that runs in the background.
"""

import threading
import time
from datetime import datetime, timedelta
from typing import Callable, Optional

# ---------------------------------------------------------------------------
# Plyer import with graceful fallback
# ---------------------------------------------------------------------------
try:
    from plyer import notification as plyer_notify
    PLYER_AVAILABLE = True
except ImportError:
    PLYER_AVAILABLE = False
    print("[notifications] plyer not found — falling back to console alerts.")


# ---------------------------------------------------------------------------
# Passive-aggressive message pool (rotates daily so it never gets stale)
# ---------------------------------------------------------------------------
PASSIVE_AGGRESSIVE_MESSAGES = [
    "Still not posted? Wow. Okay. Cool. Just sitting here.",
    "Your content is aging like milk. Edit and Post — NOW.",
    "Nobody's going to see it if it stays in drafts. Just saying.",
    "The algorithm waits for no one. Least of all you.",
    "It's 9 PM. Your followers expected this hours ago.",
    "Draft ≠ Posted. In case you forgot. Again.",
    "Every minute you wait, someone else is posting. Think about that.",
    "Your future self will cringe at this delay. Edit and Post.",
    "The checklist called. It wants to be finished.",
    "Productivity is cute. Finishing things is better. Edit. Post. Now.",
]


def _get_message_for_today() -> str:
    """Returns a deterministic message based on the day of year."""
    day_of_year = datetime.now().timetuple().tm_yday
    return PASSIVE_AGGRESSIVE_MESSAGES[day_of_year % len(PASSIVE_AGGRESSIVE_MESSAGES)]


# ---------------------------------------------------------------------------
# Core notification sender
# ---------------------------------------------------------------------------
def send_notification(title: str, message: str, timeout: int = 10) -> bool:
    """
    Send a system notification using plyer.
    Falls back to a console print if plyer is unavailable.

    Args:
        title:   Notification title shown in the system tray / banner.
        message: Body text of the notification.
        timeout: Seconds before the notification auto-dismisses (desktop only).

    Returns:
        True if notification was sent, False on failure.
    """
    if PLYER_AVAILABLE:
        try:
            plyer_notify.notify(
                title=title,
                message=message,
                app_name="Content Checklist",
                app_icon=None,   # Replace with path to .ico/.png for branded icon
                timeout=timeout,
            )
            return True
        except Exception as exc:
            print(f"[notifications] plyer error: {exc}")

    # Fallback: console alert with visual separation
    border = "=" * 60
    print(f"\n{border}")
    print(f"  NOTIFICATION: {title}")
    print(f"  {message}")
    print(f"{border}\n")
    return False


# ---------------------------------------------------------------------------
# 9 PM daily logic check
# ---------------------------------------------------------------------------
def check_and_remind(get_unfinished_items: Callable[[], list]) -> None:
    """
    Called at 9 PM. Fetches unfinished checklist items and fires
    a passive-aggressive notification if any exist.

    Args:
        get_unfinished_items: A zero-argument callable that returns a list
                              of unfinished item labels/strings. Provide this
                              from your checklist data layer.
    """
    unfinished = get_unfinished_items()

    if not unfinished:
        # Everything done — send a positive reinforcement notification
        send_notification(
            title="Checklist Complete!",
            message="All items finished before 9 PM. You are crushing it today.",
            timeout=8,
        )
        return

    count = len(unfinished)
    item_preview = ", ".join(unfinished[:3])
    if count > 3:
        item_preview += f" (+{count - 3} more)"

    message = (
        f"{_get_message_for_today()}\n"
        f"Unfinished ({count}): {item_preview}"
    )

    send_notification(
        title="Edit and Post — Seriously.",
        message=message,
        timeout=30,   # Linger longer so it cannot be ignored
    )
    print(f"[notifications] 9 PM reminder sent. Unfinished items: {unfinished}")


# ---------------------------------------------------------------------------
# Scheduler — runs in a daemon thread
# ---------------------------------------------------------------------------
class DailyReminderScheduler:
    """
    Lightweight scheduler that fires check_and_remind() every day at
    REMINDER_HOUR:REMINDER_MINUTE local time.

    Usage:
        scheduler = DailyReminderScheduler(get_unfinished_items=my_fn)
        scheduler.start()          # non-blocking; runs in background
        ...
        scheduler.stop()           # clean shutdown
    """

    REMINDER_HOUR   = 21   # 9 PM local time
    REMINDER_MINUTE = 0    # :00

    def __init__(self, get_unfinished_items: Callable[[], list]):
        self._get_unfinished = get_unfinished_items
        self._stop_event     = threading.Event()
        self._thread: Optional[threading.Thread] = None

    def _seconds_until_next_trigger(self) -> float:
        """Calculates seconds until the next 9:00 PM trigger."""
        now = datetime.now()
        target = now.replace(
            hour=self.REMINDER_HOUR,
            minute=self.REMINDER_MINUTE,
            second=0,
            microsecond=0,
        )
        if now >= target:
            target += timedelta(days=1)
        return (target - now).total_seconds()

    def _run(self) -> None:
        print("[notifications] Scheduler started. Waiting for 9 PM trigger.")
        while not self._stop_event.is_set():
            wait_seconds = self._seconds_until_next_trigger()
            hours_left   = wait_seconds / 3600
            print(f"[notifications] Next reminder in {hours_left:.1f} hours.")

            # Sleep in 60-second chunks so stop() responds quickly
            slept = 0.0
            while slept < wait_seconds and not self._stop_event.is_set():
                chunk = min(60.0, wait_seconds - slept)
                time.sleep(chunk)
                slept += chunk

            if not self._stop_event.is_set():
                check_and_remind(self._get_unfinished)

    def start(self) -> None:
        """Start the background scheduler thread."""
        if self._thread and self._thread.is_alive():
            print("[notifications] Scheduler already running.")
            return
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._run, daemon=True, name="DailyReminder"
        )
        self._thread.start()

    def stop(self) -> None:
        """Signal the scheduler to stop after the current sleep chunk."""
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=65)
        print("[notifications] Scheduler stopped.")

    def trigger_now(self) -> None:
        """Manually fire the reminder logic immediately (useful for testing)."""
        check_and_remind(self._get_unfinished)


# ---------------------------------------------------------------------------
# Convenience factory
# ---------------------------------------------------------------------------
def create_scheduler(get_unfinished_items: Callable[[], list]) -> DailyReminderScheduler:
    """
    Create and return a DailyReminderScheduler without starting it.
    Call .start() when your app finishes initialising.
    """
    return DailyReminderScheduler(get_unfinished_items=get_unfinished_items)
