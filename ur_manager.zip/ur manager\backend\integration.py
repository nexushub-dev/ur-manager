"""
integration.py — System Integration Layer
Part 4: Wiring notifications into the app entry point
────────────────────────────────────────────────────────
This file shows exactly how to plug the DailyReminderScheduler
from notifications.py into whatever main.py / app.py was built
in Parts 1–3.

Drop-in pattern:
    from integration import setup_notifications, teardown_notifications

Call setup_notifications(checklist_store) right after your app
object is constructed, and teardown_notifications() on exit.
"""

from __future__ import annotations

import atexit
import sys
from typing import TYPE_CHECKING

from notifications import create_scheduler, send_notification

if TYPE_CHECKING:
    # Replace this import with your actual data store class from P1–P3
    from checklist_store import ChecklistStore   # noqa: F401


# Module-level handle so we can stop the scheduler cleanly on exit
_scheduler = None


# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────

def setup_notifications(store) -> None:
    """
    Wire up the daily 9 PM reminder to your checklist data store.

    Args:
        store: Any object that exposes a method returning a list of
               unfinished item labels, e.g.:
                   store.get_unfinished_labels() -> list[str]

    Call this once after your app and data layer are initialised.
    """
    global _scheduler

    def _get_unfinished() -> list:
        """Bridge between the scheduler and the data layer."""
        try:
            # Adjust the method name to match your actual store API
            if hasattr(store, "get_unfinished_labels"):
                return store.get_unfinished_labels()
            if hasattr(store, "unfinished_items"):
                return [item.label for item in store.unfinished_items()]
            # Fallback — return an empty list so no spurious alerts fire
            return []
        except Exception as exc:
            print(f"[integration] Could not fetch unfinished items: {exc}")
            return []

    _scheduler = create_scheduler(get_unfinished_items=_get_unfinished)
    _scheduler.start()

    # Ensure clean shutdown even on abrupt exits
    atexit.register(teardown_notifications)

    print("[integration] Daily notification scheduler started.")

    # Send a welcome notification on first launch (one-time)
    _send_welcome_if_first_launch()


def teardown_notifications() -> None:
    """Stop the background scheduler. Safe to call multiple times."""
    global _scheduler
    if _scheduler is not None:
        _scheduler.stop()
        _scheduler = None


def test_notification_now() -> None:
    """
    Fire the 9 PM passive-aggressive reminder immediately.
    Useful during development: call from a debug button in your UI.
    """
    if _scheduler:
        _scheduler.trigger_now()
    else:
        send_notification(
            title="Test Notification",
            message="Scheduler not running — call setup_notifications() first.",
        )


# ─────────────────────────────────────────────────────────────────────────────
# Internal helpers
# ─────────────────────────────────────────────────────────────────────────────

def _send_welcome_if_first_launch() -> None:
    """
    Checks a local flag file to determine if this is first launch,
    then sends a friendly onboarding notification.
    """
    import os
    flag_path = os.path.join(_data_dir(), ".welcomed")
    if not os.path.exists(flag_path):
        send_notification(
            title="Content Checklist Ready",
            message="Your daily 9 PM reminder is set. Don't make it remind you.",
            timeout=6,
        )
        try:
            open(flag_path, "w").close()
        except OSError:
            pass   # Non-fatal; welcome will show again next launch


def _data_dir() -> str:
    """Returns the appropriate writable data directory per platform."""
    import os
    if sys.platform == "android":
        # Android: use the app's internal private storage
        try:
            from android.storage import app_storage_path  # type: ignore
            return app_storage_path()
        except ImportError:
            pass
    # iOS / desktop fallback
    home = os.path.expanduser("~")
    data = os.path.join(home, ".contentchecklist")
    os.makedirs(data, exist_ok=True)
    return data


# ─────────────────────────────────────────────────────────────────────────────
# Example main.py integration snippet (copy into your actual main.py)
# ─────────────────────────────────────────────────────────────────────────────
EXAMPLE_MAIN_SNIPPET = '''
# ── In your main.py / app.py ──────────────────────────────────────────────

from integration import setup_notifications, teardown_notifications

class MyApp(App):                      # or ft.app() if using Flet
    def build(self):
        self.store = ChecklistStore()  # your data layer from P1–P3
        setup_notifications(self.store)
        return RootWidget()

    def on_stop(self):
        teardown_notifications()

# ─────────────────────────────────────────────────────────────────────────────
'''

if __name__ == "__main__":
    # Quick smoke-test without a real store
    class _MockStore:
        def get_unfinished_labels(self):
            return ["Edit Monday reel", "Write caption", "Post to Instagram"]

    print("Running integration smoke test ...")
    setup_notifications(_MockStore())
    print("Triggering test notification now ...")
    test_notification_now()
    teardown_notifications()
    print("Done.")
