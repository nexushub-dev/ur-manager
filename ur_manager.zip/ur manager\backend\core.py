"""
core.py — Social Media Growth App Core Logic
Handles User model, account age calculation, task engine, and local storage persistence.
Storage uses a local JSON file (~/.smg_data.json) — compatible with all Flet versions.
"""

from datetime import date
from dataclasses import dataclass, field
from typing import Optional
from pathlib import Path
import json
import flet as ft


# ─────────────────────────────────────────────
# Constants
# ─────────────────────────────────────────────

WARMUP_PHASE_DAYS = 14          # Day 1–14
STORAGE_KEY_USER  = "smg_user"  # client_storage key


WARMUP_TASKS: list[str] = [
    "Follow 10–15 accounts in your niche",
    "Like 20–30 posts relevant to your niche",
    "Leave 5 genuine comments on popular posts",
    "Post one piece of content (photo / reel / tweet)",
    "Optimize your bio and profile picture",
    "Engage with 3 accounts that recently followed you",
    "Research the top 5 hashtags in your niche",
    "Watch 10 trending videos in your niche for inspiration",
    "Reply to every comment on your own posts",
    "Schedule tomorrow's content tonight",
    "Identify 3 potential collaboration partners",
    "Check your analytics and note your best-performing post",
    "Follow 5 micro-influencers in your niche",
    "Write a short thread or carousel about your story",
]

GROWTH_TASKS: list[str] = [
    "Publish 2–3 pieces of content today",
    "Run a poll or question sticker to boost engagement",
    "Collaborate with or re-share a creator in your niche",
    "Analyse last week's top-performing post and replicate its format",
    "Reach out to one brand or creator for a shout-out",
    "Go live for at least 15 minutes",
    "Respond to every DM within 2 hours",
    "Cross-post your best content to a secondary platform",
    "Write a long-form caption with a strong CTA",
    "Audit your hashtag strategy and test a new set",
    "Pin your best comment on a viral post in your niche",
    "Create a 'save-worthy' infographic or carousel",
    "Update your link-in-bio with fresh content",
    "Post a behind-the-scenes story or reel",
    "Set a monthly growth goal and post it publicly",
]


# ─────────────────────────────────────────────
# User Model
# ─────────────────────────────────────────────

@dataclass
class User:
    """Stores the user's niche, selected platforms, and account creation date."""

    niche: str = ""
    platforms: list[str] = field(default_factory=list)
    creation_date: date = field(default_factory=date.today)

    # ── Serialisation ─────────────────────────

    def to_dict(self) -> dict:
        return {
            "niche": self.niche,
            "platforms": self.platforms,
            "creation_date": self.creation_date.isoformat(),
        }

    @classmethod
    def from_dict(cls, data: dict) -> "User":
        return cls(
            niche=data.get("niche", ""),
            platforms=data.get("platforms", []),
            creation_date=date.fromisoformat(
                data.get("creation_date", date.today().isoformat())
            ),
        )

    def to_json(self) -> str:
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, raw: str) -> "User":
        return cls.from_dict(json.loads(raw))


# ─────────────────────────────────────────────
# Account Age Helper
# ─────────────────────────────────────────────

def calculate_account_age(creation_date: date) -> int:
    """
    Returns the number of days since `creation_date` (inclusive Day 1 = today if just created).
    Always returns at least 1.
    """
    delta = (date.today() - creation_date).days + 1   # Day 1 on creation day
    return max(delta, 1)


# ─────────────────────────────────────────────
# Phase Detection
# ─────────────────────────────────────────────

def get_phase(account_age_days: int) -> str:
    """Returns 'Warm-up Phase' or 'Growth Phase' based on account age."""
    if account_age_days <= WARMUP_PHASE_DAYS:
        return "Warm-up Phase"
    return "Growth Phase"


# ─────────────────────────────────────────────
# Task Engine
# ─────────────────────────────────────────────

class TaskEngine:
    """
    Returns a daily task list tailored to the current growth phase.

    Warm-up Phase  (Day 1–14)  → foundation-building tasks
    Growth Phase   (Day 15+)   → scaling and monetisation tasks
    """

    @staticmethod
    def get_tasks(account_age_days: int) -> list[str]:
        phase = get_phase(account_age_days)
        if phase == "Warm-up Phase":
            return list(WARMUP_TASKS)
        return list(GROWTH_TASKS)

    @staticmethod
    def get_tasks_for_user(user: User) -> list[str]:
        age = calculate_account_age(user.creation_date)
        return TaskEngine.get_tasks(age)


# ─────────────────────────────────────────────
# Storage Helpers  (local JSON file)
# ─────────────────────────────────────────────

STORAGE_FILE = Path.home() / ".smg_data.json"


class StorageManager:
    """
    Persists all app data to a single JSON file at ~/.smg_data.json.
    Replaces page.client_storage (removed in newer Flet versions).
    All methods are synchronous — no async needed for file I/O here.
    """

    def _read(self) -> dict:
        """Load the full data dict from disk, or return empty dict."""
        try:
            return json.loads(STORAGE_FILE.read_text(encoding="utf-8"))
        except (FileNotFoundError, json.JSONDecodeError):
            return {}

    def _write(self, data: dict) -> None:
        """Write the full data dict to disk."""
        STORAGE_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")

    # ── User persistence ──────────────────────

    def save_user(self, user: User) -> None:
        """Persist the full User object."""
        data = self._read()
        data[STORAGE_KEY_USER] = user.to_dict()
        self._write(data)

    def load_user(self) -> Optional[User]:
        """Load and return a User, or None if not found."""
        data = self._read()
        raw = data.get(STORAGE_KEY_USER)
        if raw is None:
            return None
        try:
            return User.from_dict(raw)
        except (KeyError, ValueError):
            return None

    def clear_user(self) -> None:
        """Remove the stored User (reset / logout)."""
        data = self._read()
        data.pop(STORAGE_KEY_USER, None)
        self._write(data)

    # ── Checkbox / task state persistence ─────

    def _task_key(self, task_label: str) -> str:
        safe = task_label.replace(" ", "_").replace("/", "-")[:60]
        return f"task__{safe}"

    def save_task_checked(self, task_label: str, checked: bool) -> None:
        data = self._read()
        data[self._task_key(task_label)] = checked
        self._write(data)

    def load_task_checked(self, task_label: str) -> bool:
        return bool(self._read().get(self._task_key(task_label), False))

    # ── Niche shortcut ────────────────────────

    def save_niche(self, niche: str) -> None:
        data = self._read()
        data["smg_niche"] = niche
        self._write(data)

    def load_niche(self) -> str:
        return self._read().get("smg_niche", "")


# ─────────────────────────────────────────────
# Minimal Flet Demo  (python core.py to test)
# ─────────────────────────────────────────────

def main(page: ft.Page):
    page.title = "SMG Core – Demo"
    page.scroll = ft.ScrollMode.AUTO
    page.padding = 24

    storage = StorageManager()   # no page arg needed
    engine  = TaskEngine()

    # ── State ─────────────────────────────────
    user_ref: list[Optional[User]] = [None]

    status_text  = ft.Text("", color=ft.Colors.GREEN_400, size=13)
    phase_banner = ft.Text("", size=16, weight=ft.FontWeight.BOLD)
    task_column  = ft.Column(spacing=6)

    # ── Helpers ───────────────────────────────

    def refresh_ui(user: User):
        age   = calculate_account_age(user.creation_date)
        phase = get_phase(age)
        tasks = engine.get_tasks(age)

        phase_banner.value = (
            f"Day {age}  .  {phase}  .  Niche: {user.niche or '(none)'}"
        )

        task_column.controls.clear()
        for task in tasks:
            cb = ft.Checkbox(label=task, value=storage.load_task_checked(task))

            def on_change(e, t=task, c=cb):
                storage.save_task_checked(t, c.value)
                status_text.value = f"Saved: '{t[:40]}...' = {c.value}"
                page.update()

            cb.on_change = on_change
            task_column.controls.append(cb)

        page.update()

    # ── Niche field ───────────────────────────
    niche_field = ft.TextField(
        label="Your Niche",
        hint_text="e.g. fitness, travel, coding...",
        width=320,
    )

    def on_niche_submit(e):
        niche = niche_field.value.strip()
        user  = user_ref[0] or User()
        user.niche = niche
        user_ref[0] = user
        storage.save_user(user)
        storage.save_niche(niche)
        status_text.value = f"Niche saved: {niche}"
        refresh_ui(user)

    niche_field.on_submit = on_niche_submit
    save_btn = ft.ElevatedButton("Save Niche", on_click=on_niche_submit)

    # ── Initialise ────────────────────────────
    loaded = storage.load_user()
    if loaded:
        user_ref[0] = loaded
        niche_field.value = loaded.niche
        status_text.value = "Loaded from storage ✓"
    else:
        user_ref[0] = User()
        status_text.value = "New user – no data found"

    refresh_ui(user_ref[0])

    page.add(
        ft.Text("Social Media Growth – Core Demo", size=22, weight=ft.FontWeight.BOLD),
        ft.Divider(),
        ft.Row([niche_field, save_btn], alignment=ft.MainAxisAlignment.START),
        status_text,
        ft.Divider(),
        phase_banner,
        ft.Text("Today's Tasks", size=15, weight=ft.FontWeight.W_600),
        task_column,
    )


if __name__ == "__main__":
    ft.app(target=main)
