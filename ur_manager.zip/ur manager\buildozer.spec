[app]

# ─────────────────────────────────────────────────────────────────────────────
# APP IDENTITY
# ─────────────────────────────────────────────────────────────────────────────
title           = Content Checklist
package.name    = contentchecklist
package.domain  = com.yourapp

# Entry point — the main Python file Buildozer compiles
source.dir      = .
source.include_exts = py,png,jpg,kv,atlas,json,db,xml,plist

# Main module (must match your main .py filename without extension)
# If your entry is main.py, leave as "main". If app.py, change accordingly.
source.main      = main

version          = 1.0.0


# ─────────────────────────────────────────────────────────────────────────────
# PYTHON REQUIREMENTS
# All third-party packages needed at runtime.
# Buildozer downloads and cross-compiles these automatically.
# ─────────────────────────────────────────────────────────────────────────────
requirements =
    # Core framework — choose ONE:
    kivy==2.3.0,          # Kivy-based UI
    # flet,               # Uncomment if using Flet instead

    # Notification backend
    plyer==2.1.0,

    # Data persistence
    tinydb==4.8.0,

    # Utilities
    python-dateutil==2.9.0,
    requests==2.31.0,

    # Android-specific extras (ignored on iOS build)
    android,
    pyjnius


# ─────────────────────────────────────────────────────────────────────────────
# ORIENTATION & DISPLAY
# ─────────────────────────────────────────────────────────────────────────────
orientation     = portrait
fullscreen      = 0


# ─────────────────────────────────────────────────────────────────────────────
# ICONS & SPLASH
# Place these files in your project root or adjust paths accordingly.
# ─────────────────────────────────────────────────────────────────────────────
icon.filename   = %(source.dir)s/assets/icon.png
presplash.filename = %(source.dir)s/assets/splash.png

# Splash screen background colour (hex, no #)
android.presplash_color = #1A1A2E


# ─────────────────────────────────────────────────────────────────────────────
# ANDROID CONFIGURATION
# ─────────────────────────────────────────────────────────────────────────────
[android]

# SDK / NDK Versions — use the latest stable pair
android.minapi          = 21
android.ndk             = 25b
android.sdk             = 34
android.ndk_api         = 21

# Architecture targets — build a fat APK or split into AABs
android.archs           = arm64-v8a, armeabi-v7a

# API targets for the Google Play Store (AAB required for new apps)
android.release_artifact = apk     # Change to "aab" for Play Store submission

# Custom manifest — uses our AndroidManifest.xml from Part 4
android.manifest        = AndroidManifest.xml

# Permissions declared in the manifest; Buildozer also injects these
# so they appear in both the manifest AND the Buildozer permission layer.
android.permissions =
    READ_EXTERNAL_STORAGE,
    WRITE_EXTERNAL_STORAGE,
    POST_NOTIFICATIONS,
    FOREGROUND_SERVICE,
    SCHEDULE_EXACT_ALARM,
    USE_EXACT_ALARM,
    WAKE_LOCK,
    RECEIVE_BOOT_COMPLETED

# Broadcast receivers, services, and providers referenced in the manifest
# Buildozer needs to know about these so it merges them correctly.
android.add_activities      = org.kivy.android.PythonActivity
android.add_services        = org.kivy.android.PythonService
android.add_receivers       = .BootReceiver, .DailyReminderReceiver

# Gradle dependencies — needed for AlarmManager and notification compat
android.gradle_dependencies =
    androidx.core:core-ktx:1.12.0,
    androidx.work:work-runtime:2.9.0,
    com.google.android.material:material:1.11.0

# Proguard / R8 for release builds (keeps app size down)
android.release_minify   = 1
android.proguard_rules   = proguard-rules.pro

# Gradle build settings
android.gradle_plugin_version = 8.2.2
android.gradle_version    = 8.6

# Signing — fill these in before making a release build
# android.keystore         = path/to/your.keystore
# android.keystore_alias   = your_alias
# android.keystore_password = your_password
# android.keyalias_password = your_alias_password

# Enable AndroidX (required by most modern libraries)
android.enable_androidx  = True

# Java version
android.java_version      = 17

# ─────────────────────────────────────────────────────────────────────────────
# iOS CONFIGURATION
# Note: iOS builds require a macOS host with Xcode 15+ installed.
# Run:  buildozer ios debug deploy  (on macOS only)
# ─────────────────────────────────────────────────────────────────────────────
[ios]

# Custom Info.plist from Part 4
ios.info_plist          = Info.plist

# iOS deployment target (minimum iOS version)
ios.deployment_target   = 14.0

# Codesigning — required for device deploy and App Store submission
# ios.codesign.allowed     = true
# ios.codesign.developer_id = iPhone Developer: Your Name (TEAMID)

# Kivy iOS version
ios.kivy_ios_url        = https://github.com/kivy/kivy-ios
ios.kivy_ios_branch     = master


# ─────────────────────────────────────────────────────────────────────────────
# BUILDOZER / BUILD SYSTEM
# ─────────────────────────────────────────────────────────────────────────────
[buildozer]

# Buildozer working directory (stores NDK, SDK downloads)
build_dir   = .buildozer

# Directory where the final .apk / .ipa will be placed
bin_dir     = bin

# Log level: 0 = error only, 1 = info, 2 = debug (verbose)
log_level   = 1

# Warn if buildozer.spec appears to use default/example values
warn_on_root = 1
