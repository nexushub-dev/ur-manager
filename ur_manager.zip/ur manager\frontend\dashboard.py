"""
Glassmorphism Dashboard — Python Flet
Dark atmospheric UI with frosted glass cards, neon accents, and smoke/mist depth layers.
"""

import flet as ft
import math


# ── Palette ────────────────────────────────────────────────────────────────────
BG_DEEP        = "#0A0010"          # near-black deep purple
BG_MID         = "#110020"
GLASS_BG       = "#FFFFFF1A"        # white @ 10 %
GLASS_BORDER   = "#FFFFFF33"        # white @ 20 %
NEON_BLUE      = "#00D4FF"
NEON_PURPLE    = "#BF5FFF"
NEON_RED       = "#FF2D55"
TEXT_PRIMARY   = "#FFFFFF"
TEXT_SECONDARY = "#FFFFFFB2"        # white @ 70 %
TEXT_DIM       = "#FFFFFF66"        # white @ 40 %
ACCENT_GLOW    = "#4400AA"


# ── Helpers ────────────────────────────────────────────────────────────────────

def neon_text(value: str, size=14, color=NEON_BLUE, weight=ft.FontWeight.W_600, **kw):
    return ft.Text(value, size=size, color=color, weight=weight, **kw)


def label(value: str, size=11, color=TEXT_DIM):
    return ft.Text(value.upper(), size=size, color=color,
                   weight=ft.FontWeight.W_500,
                   letter_spacing=2)


def glass_card(content, padding=20, border_color=GLASS_BORDER, glow=False, expand=False):
    """Semi-transparent frosted-glass container."""
    shadow_color = NEON_BLUE if glow else "#00000000"
    return ft.Container(
        content=content,
        padding=padding,
        bgcolor=GLASS_BG,
        border_radius=16,
        border=ft.border.all(1, border_color),
        shadow=ft.BoxShadow(
            spread_radius=0,
            blur_radius=24 if glow else 8,
            color=ft.colors.with_opacity(0.35 if glow else 0.15, shadow_color),
            offset=ft.Offset(0, 4),
        ),
        blur=ft.Blur(8, 8),
        expand=expand,
    )


def divider():
    return ft.Container(height=1, bgcolor=GLASS_BORDER, margin=ft.margin.symmetric(vertical=8))


# ── Atmospheric Background ─────────────────────────────────────────────────────

def build_background() -> ft.Stack:
    """
    Layered gradient circles + a translucent noise-like mist to
    replicate the dark smoke / red-mist atmosphere from the reference.
    """
    def blob(left, top, width, height, color, blur=120, opacity=0.35):
        return ft.Container(
            left=left, top=top,
            width=width, height=height,
            bgcolor=ft.colors.with_opacity(opacity, color),
            blur=ft.Blur(blur, blur),
            border_radius=999,
        )

    return ft.Stack(
        expand=True,
        controls=[
            # Base background
            ft.Container(expand=True, bgcolor=BG_DEEP),

            # Deep purple blob — top-left
            blob(-80, -60, 340, 340, "#6600CC", blur=120, opacity=0.45),

            # Red-mist blob — bottom right (the "smoke" element)
            blob(180, 480, 260, 280, "#CC0033", blur=140, opacity=0.30),

            # Secondary glow — centre
            blob(60, 280, 200, 200, "#3300AA", blur=100, opacity=0.25),

            # Faint teal shimmer — top-right
            blob(280, 60, 180, 160, "#003366", blur=90, opacity=0.20),

            # Very subtle red flare — left mid
            blob(-40, 420, 160, 160, "#990000", blur=80, opacity=0.18),
        ],
    )


# ── Header ─────────────────────────────────────────────────────────────────────

def build_header() -> ft.Container:
    return ft.Container(
        content=ft.Row(
            controls=[
                ft.Column(
                    controls=[
                        ft.Row(
                            controls=[
                                ft.Container(
                                    width=8, height=8,
                                    bgcolor=NEON_RED,
                                    border_radius=50,
                                    shadow=ft.BoxShadow(
                                        blur_radius=12,
                                        color=ft.colors.with_opacity(0.9, NEON_RED),
                                    ),
                                ),
                                ft.Container(width=6),
                                ft.Text("LIVE", size=10, color=NEON_RED,
                                        weight=ft.FontWeight.W_700,
                                        letter_spacing=2),
                            ],
                            spacing=0,
                        ),
                        ft.Container(height=4),
                        ft.Text("NICHE DASHBOARD", size=22,
                                color=TEXT_PRIMARY,
                                weight=ft.FontWeight.W_800,
                                letter_spacing=1),
                        ft.Text("14-Day Warm-up Protocol", size=12,
                                color=TEXT_DIM,
                                letter_spacing=1),
                    ],
                    spacing=0,
                ),
                ft.Container(expand=True),
                # Avatar / settings icon
                ft.Container(
                    content=ft.Icon(ft.icons.PERSON_OUTLINE,
                                    color=NEON_BLUE, size=20),
                    width=44, height=44,
                    bgcolor=GLASS_BG,
                    border_radius=22,
                    border=ft.border.all(1, NEON_BLUE + "55"),
                    alignment=ft.alignment.center,
                ),
            ],
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
        ),
        padding=ft.padding.only(left=20, right=20, top=54, bottom=12),
    )


# ── Niche Display Card ─────────────────────────────────────────────────────────

def build_niche_card() -> ft.Container:
    tags = ["AI Tools", "Productivity", "SaaS"]

    tag_chips = ft.Row(
        controls=[
            ft.Container(
                content=ft.Text(t, size=11, color=NEON_BLUE,
                                weight=ft.FontWeight.W_600),
                padding=ft.padding.symmetric(horizontal=10, vertical=4),
                bgcolor=ft.colors.with_opacity(0.15, NEON_BLUE),
                border_radius=20,
                border=ft.border.all(1, NEON_BLUE + "44"),
            )
            for t in tags
        ],
        spacing=8,
        wrap=True,
    )

    return glass_card(
        glow=True,
        border_color=NEON_BLUE + "55",
        content=ft.Column(
            controls=[
                ft.Row(
                    controls=[
                        label("Current Niche"),
                        ft.Container(expand=True),
                        ft.Icon(ft.icons.EDIT_OUTLINED, color=TEXT_DIM, size=16),
                    ],
                ),
                ft.Container(height=8),
                ft.Text("Micro-SaaS\nfor Creators", size=26,
                        color=TEXT_PRIMARY,
                        weight=ft.FontWeight.W_800,
                        height=1.2),
                ft.Container(height=12),
                tag_chips,
                divider(),
                ft.Row(
                    controls=[
                        ft.Column(
                            controls=[
                                neon_text("4.2K", size=18),
                                label("Avg. TAM"),
                            ],
                            spacing=2, horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                        ),
                        ft.VerticalDivider(color=GLASS_BORDER, width=1),
                        ft.Column(
                            controls=[
                                neon_text("87%", size=18, color=NEON_PURPLE),
                                label("Fit Score"),
                            ],
                            spacing=2, horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                        ),
                        ft.VerticalDivider(color=GLASS_BORDER, width=1),
                        ft.Column(
                            controls=[
                                neon_text("↑ 12%", size=18, color="#00FF88"),
                                label("7d Trend"),
                            ],
                            spacing=2, horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                        ),
                    ],
                    alignment=ft.MainAxisAlignment.SPACE_AROUND,
                ),
            ],
            spacing=0,
        ),
    )


# ── Warm-up Progress ───────────────────────────────────────────────────────────

def build_warmup_card(current_day: int = 7) -> ft.Container:
    total = 14
    pct = current_day / total

    # Day pips
    def day_pip(i):
        done = i < current_day
        active = i == current_day
        color = NEON_BLUE if done else (NEON_PURPLE if active else GLASS_BORDER)
        return ft.Container(
            width=18, height=18,
            border_radius=9,
            bgcolor=ft.colors.with_opacity(0.25 if done else 0.05, color),
            border=ft.border.all(1.5 if active else 1, color),
            alignment=ft.alignment.center,
            content=ft.Text(str(i + 1), size=8,
                            color=color if done or active else TEXT_DIM,
                            weight=ft.FontWeight.W_700),
            shadow=ft.BoxShadow(
                blur_radius=8, color=ft.colors.with_opacity(0.6, color),
            ) if active else None,
        )

    pip_rows = ft.Row(
        controls=[day_pip(i) for i in range(total)],
        spacing=5,
        wrap=True,
    )

    return glass_card(
        content=ft.Column(
            controls=[
                ft.Row(
                    controls=[
                        label("Warm-up Progress"),
                        ft.Container(expand=True),
                        neon_text(f"Day {current_day}", size=13, color=NEON_PURPLE),
                        ft.Text(f" / {total}", size=13, color=TEXT_DIM),
                    ],
                ),
                ft.Container(height=10),
                # Progress bar
                ft.Stack(
                    height=6,
                    controls=[
                        ft.Container(
                            height=6, border_radius=3,
                            bgcolor=ft.colors.with_opacity(0.15, NEON_BLUE),
                            expand=True,
                        ),
                        ft.Container(
                            height=6, border_radius=3,
                            width=None,
                            bgcolor=ft.colors.with_opacity(0.0, "#000"),
                            gradient=ft.LinearGradient(
                                begin=ft.alignment.center_left,
                                end=ft.alignment.center_right,
                                colors=[NEON_PURPLE, NEON_BLUE],
                            ),
                            # Flet doesn't support fractional width; use a Row trick
                        ),
                    ],
                ),
                # Custom thin progress
                ft.Container(
                    content=ft.Row(
                        controls=[
                            ft.Container(
                                expand=int(current_day * 10),
                                height=4,
                                gradient=ft.LinearGradient(
                                    begin=ft.alignment.center_left,
                                    end=ft.alignment.center_right,
                                    colors=[NEON_PURPLE, NEON_BLUE],
                                ),
                                border_radius=ft.BorderRadius(2, 0, 2, 0),
                                shadow=ft.BoxShadow(
                                    blur_radius=10,
                                    color=ft.colors.with_opacity(0.8, NEON_BLUE),
                                ),
                            ),
                            ft.Container(
                                expand=int((total - current_day) * 10),
                                height=4,
                                bgcolor=ft.colors.with_opacity(0.12, "#FFFFFF"),
                                border_radius=ft.BorderRadius(0, 2, 0, 2),
                            ),
                        ],
                        spacing=0,
                    ),
                    border_radius=3,
                    clip_behavior=ft.ClipBehavior.HARD_EDGE,
                ),
                ft.Container(height=12),
                pip_rows,
            ],
            spacing=4,
        ),
    )


# ── Daily Checklist ────────────────────────────────────────────────────────────

TASKS = [
    ("Research 3 competitor products", True,  NEON_BLUE),
    ("Post value thread on X/Twitter",  True,  NEON_BLUE),
    ("Cold DM 5 target accounts",        True,  NEON_BLUE),
    ("Update landing page headline",     False, NEON_PURPLE),
    ("Record 60-sec product demo",       False, NEON_PURPLE),
    ("Publish 1 insight to newsletter",  False, NEON_RED),
]


def build_checklist_card(page: ft.Page) -> ft.Container:
    def make_row(text, done, accent):
        icon = ft.Icon(
            ft.icons.CHECK_CIRCLE if done else ft.icons.RADIO_BUTTON_UNCHECKED,
            color=accent if done else TEXT_DIM,
            size=18,
        )
        label_text = ft.Text(
            text,
            size=13,
            color=TEXT_SECONDARY if done else TEXT_PRIMARY,
            weight=ft.FontWeight.W_400 if done else ft.FontWeight.W_500,
            style=ft.TextStyle(
                decoration=ft.TextDecoration.LINE_THROUGH if done else None,
                decoration_color=TEXT_DIM,
            ),
        )
        return ft.Container(
            content=ft.Row(
                controls=[icon, ft.Container(width=10), label_text],
                spacing=0,
            ),
            padding=ft.padding.symmetric(vertical=9, horizontal=4),
            border=ft.border.only(bottom=ft.BorderSide(1, GLASS_BORDER)),
        )

    done_count = sum(1 for _, d, _ in TASKS if d)
    total_count = len(TASKS)

    rows = ft.Column(
        controls=[make_row(t, d, a) for t, d, a in TASKS],
        spacing=0,
    )

    return glass_card(
        content=ft.Column(
            controls=[
                ft.Row(
                    controls=[
                        label("Today's Tasks"),
                        ft.Container(expand=True),
                        ft.Container(
                            content=ft.Text(
                                f"{done_count}/{total_count}",
                                size=12,
                                color=NEON_BLUE,
                                weight=ft.FontWeight.W_700,
                            ),
                            padding=ft.padding.symmetric(horizontal=10, vertical=3),
                            bgcolor=ft.colors.with_opacity(0.15, NEON_BLUE),
                            border_radius=20,
                            border=ft.border.all(1, NEON_BLUE + "44"),
                        ),
                    ],
                ),
                ft.Container(height=4),
                rows,
                ft.Container(height=8),
                ft.Container(
                    content=ft.Row(
                        controls=[
                            ft.Icon(ft.icons.ADD, color=NEON_BLUE, size=16),
                            ft.Text("Add Task", size=13, color=NEON_BLUE,
                                    weight=ft.FontWeight.W_600),
                        ],
                        spacing=4,
                        alignment=ft.MainAxisAlignment.CENTER,
                    ),
                    padding=ft.padding.symmetric(vertical=10),
                    bgcolor=ft.colors.with_opacity(0.08, NEON_BLUE),
                    border_radius=10,
                    border=ft.border.all(1, NEON_BLUE + "33"),
                ),
            ],
            spacing=0,
        ),
    )


# ── Bottom Nav ─────────────────────────────────────────────────────────────────

def build_bottom_nav() -> ft.Container:
    def nav_item(icon, label_str, active=False):
        color = NEON_BLUE if active else TEXT_DIM
        return ft.Column(
            controls=[
                ft.Container(
                    content=ft.Icon(icon, color=color, size=22),
                    width=44, height=44,
                    alignment=ft.alignment.center,
                    bgcolor=ft.colors.with_opacity(0.15 if active else 0, NEON_BLUE),
                    border_radius=12,
                    border=ft.border.all(1, color + ("88" if active else "00")),
                    shadow=ft.BoxShadow(
                        blur_radius=14,
                        color=ft.colors.with_opacity(0.5 if active else 0, NEON_BLUE),
                    ) if active else None,
                ),
                ft.Text(label_str, size=10, color=color, weight=ft.FontWeight.W_500),
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=4,
        )

    return ft.Container(
        content=ft.Row(
            controls=[
                nav_item(ft.icons.DASHBOARD_OUTLINED, "Dashboard", active=True),
                nav_item(ft.icons.SHOW_CHART, "Analytics"),
                nav_item(ft.icons.EXPLORE_OUTLINED, "Niches"),
                nav_item(ft.icons.SETTINGS_OUTLINED, "Settings"),
            ],
            alignment=ft.MainAxisAlignment.SPACE_AROUND,
        ),
        padding=ft.padding.only(top=12, bottom=24, left=8, right=8),
        bgcolor=ft.colors.with_opacity(0.6, BG_MID),
        border=ft.border.only(top=ft.BorderSide(1, GLASS_BORDER)),
        blur=ft.Blur(20, 20),
    )


# ── Main ───────────────────────────────────────────────────────────────────────

def main(page: ft.Page):
    page.title       = "Niche Dashboard"
    page.bgcolor     = BG_DEEP
    page.padding     = 0
    page.fonts       = {
        "Rajdhani": "https://fonts.gstatic.com/s/rajdhani/v15/LDI2apCSOBg7S-QT7pb0EMOsc-bGkqIw.woff2",
    }
    page.theme = ft.Theme(font_family="Rajdhani")

    # Scrollable main body
    body = ft.ListView(
        controls=[
            build_header(),
            ft.Container(
                content=ft.Column(
                    controls=[
                        build_niche_card(),
                        ft.Container(height=14),
                        build_warmup_card(current_day=7),
                        ft.Container(height=14),
                        build_checklist_card(page),
                        ft.Container(height=24),
                    ],
                    spacing=0,
                ),
                padding=ft.padding.symmetric(horizontal=16),
            ),
        ],
        spacing=0,
        expand=True,
    )

    # Full page stack: bg + scrollable body + bottom nav
    page.add(
        ft.Stack(
            expand=True,
            controls=[
                build_background(),
                ft.Column(
                    controls=[
                        ft.Container(content=body, expand=True),
                        build_bottom_nav(),
                    ],
                    spacing=0,
                    expand=True,
                ),
            ],
        )
    )


ft.app(target=main)
