import os
from dotenv import load_dotenv
from supabase import create_client, Client

load_dotenv()

url = os.getenv("SUPABASE_URL")
key = os.getenv("SUPABASE_KEY")

supabase: Client = create_client(url, key)

def upload_niches():
    file_path = os.path.join('backend', 'niches.txt')

    with open(file_path, 'r', encoding='utf-8') as file:
        niches = file.readlines()

    print(f"Starting upload of {len(niches)} niches...")

    for name in niches:
        clean_name = name.strip()
        if clean_name:
            supabase.table("niches").insert({"name": clean_name}).execute()
            print(f"Uploaded: {clean_name}")

if __name__ == "__main__":
    upload_niches()